export * from './modTextSearcher';
